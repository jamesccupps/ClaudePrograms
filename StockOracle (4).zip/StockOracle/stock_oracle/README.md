# ⟐ Stock Oracle

**Multi-Signal Alternative Data Stock Prediction Framework**

Stock Oracle combines 16 unconventional data sources with machine learning to predict stock movements. It goes beyond traditional technical analysis by mining signals that most traders miss.

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    STOCK ORACLE                           │
├──────────────────────────────────────────────────────────┤
│                                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │   Reddit     │  │  SEC EDGAR  │  │ Job Postings │      │
│  │  Sentiment   │  │  Filing NLP │  │  Velocity    │      │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘      │
│         │                │                │               │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐      │
│  │Supply Chain │  │  Gov        │  │   Patent     │      │
│  │  Cascade    │  │ Contracts   │  │  Activity    │      │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘      │
│         │                │                │               │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐      │
│  │Congressional│  │  App Store  │  │ Seasonality  │      │
│  │   Trades    │  │  Rankings   │  │  Calendar    │      │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘      │
│         │                │                │               │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐      │
│  │  Weather    │  │    News     │  │  Shipping    │      │
│  │ Correlation │  │ Sentiment   │  │  Activity    │      │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘      │
│         │                │                │               │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐      │
│  │  Domain     │  │  Earnings   │  │  Employee    │      │
│  │Registration │  │  Call NLP   │  │  Sentiment   │      │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘      │
│         │                │                │               │
│         └────────────────┼────────────────┘               │
│                          ▼                                │
│              ┌───────────────────────┐                    │
│              │    Feature Engine     │                    │
│              │  (50+ derived feats)  │                    │
│              └───────────┬───────────┘                    │
│                          ▼                                │
│              ┌───────────────────────┐                    │
│              │   ML Ensemble         │                    │
│              │  Random Forest        │                    │
│              │  Gradient Boosting    │                    │
│              │  Neural Network       │                    │
│              └───────────┬───────────┘                    │
│                          ▼                                │
│              ┌───────────────────────┐                    │
│              │  PREDICTION + SCORE   │                    │
│              │  BULLISH / BEARISH /  │                    │
│              │  NEUTRAL + confidence │                    │
│              └───────────────────────┘                    │
│                                                           │
└──────────────────────────────────────────────────────────┘
```

## Signal Sources

| # | Signal | Source | API Key? | What It Detects |
|---|--------|--------|----------|----------------|
| 1 | **Price & Volume** | Yahoo Finance | No | Momentum, RSI, volume anomalies |
| 2 | **Reddit Sentiment** | Reddit JSON API | Optional | Mention velocity, weighted sentiment, bot filtering |
| 3 | **SEC Filing Timing** | EDGAR | No | Friday dumps, filing red flags |
| 4 | **Insider Trades** | EDGAR Form 4 | No | Insider buying/selling clusters |
| 5 | **Job Postings** | HN/Indeed | No | Hiring velocity, role type signals |
| 6 | **Supply Chain** | Internal mapping | No | Tier-2/3 supplier cascade opportunities |
| 7 | **Gov Contracts** | USAspending.gov | No | New contract awards |
| 8 | **Patent Activity** | USPTO PatentsView | No | Innovation bursts, tech pivots |
| 9 | **Congressional Trades** | House disclosures | No | Political insider trading patterns |
| 10 | **App Store Rankings** | Apple RSS | No | User growth, international expansion |
| 11 | **Seasonality** | Calendar math | No | Monthly patterns, day-of-week effects |
| 12 | **Weather** | Open-Meteo | No | Second-order weather impacts |
| 13 | **News Sentiment** | Google News RSS | No | Headline sentiment analysis |
| 14 | **Shipping Activity** | AIS/BDI | Partial | Container shipping patterns |
| 15 | **Domain Registration** | crt.sh | No | New product domain registrations |
| 16 | **Earnings Call NLP** | Transcript API | Yes* | Hedge words, confidence scoring |

*Marked with "Yes*" require paid APIs for full functionality but degrade gracefully.

## Quick Start

```bash
# Clone and install
cd stock_oracle
pip install -r requirements.txt

# Analyze a single stock
python -m stock_oracle.oracle AAPL

# Analyze multiple stocks
python -m stock_oracle.oracle AAPL TSLA NVDA MSFT

# Analyze default watchlist
python -m stock_oracle.oracle --watchlist

# Launch web dashboard
python -m stock_oracle.dashboard.app
# → http://localhost:5000
```

## Optional: Set API Keys

Create a `.env` file or set environment variables:

```bash
# Reddit (higher rate limits)
export REDDIT_CLIENT_ID="your_id"
export REDDIT_CLIENT_SECRET="your_secret"

# Alpha Vantage (additional price data)
export ALPHA_VANTAGE_KEY="your_key"

# News API
export NEWS_API_KEY="your_key"

# SEC EDGAR (required for insider data)
export SEC_USER_AGENT="StockOracle your@email.com"
```

## ML Training

The system works out of the box with weighted averaging. To train the ML ensemble:

```python
from stock_oracle.oracle import StockOracle

oracle = StockOracle()

# Collect training data over time
# (the system saves analysis results automatically)

# Train when you have enough data (50+ samples)
# Training data is built from historical signals + actual price outcomes
oracle.predictor.train(training_data)
```

## Extending

### Add a New Collector

```python
from stock_oracle.collectors.base import BaseCollector, SignalResult

class MyCustomCollector(BaseCollector):
    @property
    def name(self) -> str:
        return "my_signal"

    def collect(self, ticker: str) -> SignalResult:
        # Your data collection logic
        data = self._request("https://api.example.com/data")

        # Return a standardized signal
        return SignalResult(
            collector_name=self.name,
            ticker=ticker,
            signal_value=0.5,    # -1.0 to +1.0
            confidence=0.7,       # 0.0 to 1.0
            details="My custom signal details",
        )
```

Then add it to `oracle.py`'s collector list and `config.py`'s SIGNAL_WEIGHTS.

## Disclaimer

This is a research and educational tool. It is NOT financial advice.
No algorithm can predict the stock market with certainty. Past performance
does not guarantee future results. Always do your own research and
consult a financial advisor before making investment decisions.
Use at your own risk.

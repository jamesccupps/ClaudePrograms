"""WeatherOracle orchestrator — coordinates data collection, ML prediction,
and retraining across both locations independently."""

import logging
import threading
import time
import traceback
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Optional

from core.config import LOCATIONS, WEATHER_MODELS, WMO_CODES, load_config
from core.database import WeatherDB
from collectors import TempestCollector, OpenMeteoCollector, NWSCollector, HACollector
from collectors.ha_publisher import HAPublisher
from ml import MLEngine

log = logging.getLogger("WeatherOracle.engine")


class WeatherOracle:
    """Main engine: runs two independent location pipelines."""

    def __init__(self, config: dict):
        self.config = config
        self.db = WeatherDB()
        self.ml = MLEngine(self.db)

        # Collectors
        self.tempest = TempestCollector(config.get("tempest_api_token", ""))
        self.openmeteo = OpenMeteoCollector()
        self.nws = NWSCollector()
        self.ha = None
        self.ha_publisher = None
        if config.get("ha_url") and config.get("ha_token"):
            self.ha = HACollector(config["ha_url"], config["ha_token"])
            self.ha_publisher = HAPublisher(config["ha_url"], config["ha_token"])

        self._running = False
        self._thread = None
        self.callbacks = []

        # Per-location state
        self.current_obs = {}      # {location: latest obs dict}
        self.crosscheck = {}       # {location: {source: {temp_f, humidity}}}
        self.alerts = {}           # {location: [alert dicts]}
        self.nws_discussion = None

    def notify(self, msg: str):
        log.info(msg)
        for cb in self.callbacks:
            try:
                cb(msg)
            except:
                pass

    # ── Observation Collection ────────────────────────────────────────────

    def collect_observations(self):
        """Pull current observations from Tempest and HA for both locations."""
        for loc_key, loc in LOCATIONS.items():
            obs = self.tempest.get_current(loc["tempest_station"])
            if obs:
                ts = obs.pop("timestamp")
                self.db.insert_observation(loc_key, ts, "tempest", **obs)
                obs["timestamp"] = ts
                self.current_obs[loc_key] = obs
                self.notify(f"[{loc['short']}] Tempest: {obs.get('temp_f')}°F, "
                           f"{obs.get('humidity')}% RH, "
                           f"wind {obs.get('wind_mph')} mph")
            else:
                self.notify(f"[{loc['short']}] Tempest fetch FAILED")

        # HA cross-check sensors (apartment only)
        if self.ha:
            xcheck = self.ha.get_outdoor_crosscheck(self.config)
            if xcheck:
                self.crosscheck["apartment"] = xcheck
                for src, data in xcheck.items():
                    self.db.insert_observation(
                        "apartment",
                        datetime.now(timezone.utc).isoformat(),
                        src,
                        temp_f=data.get("temp_f"),
                        humidity=data.get("humidity"))
                    self.notify(f"[APT] {src}: {data.get('temp_f')}°F, "
                               f"{data.get('humidity')}% RH")

    # ── Forecast Collection ───────────────────────────────────────────────

    def collect_forecasts(self):
        """Pull forecasts from all models for both locations."""
        hours = self.config.get("forecast_hours", 72)
        for loc_key, loc in LOCATIONS.items():
            collected = 0

            # Open-Meteo models
            for mk in WEATHER_MODELS:
                if mk == "tempest_bf":
                    continue  # Handled below
                fcs = self.openmeteo.get_forecast(mk, loc["lat"], loc["lon"], hours)
                if fcs:
                    for fc in fcs:
                        self.db.insert_forecast(
                            loc_key, mk, fc["issued_at"], fc["valid_at"],
                            fc["lead_hours"],
                            temp_f=fc.get("temp_f"), humidity=fc.get("humidity"),
                            dewpoint_f=fc.get("dewpoint_f"),
                            wind_mph=fc.get("wind_mph"),
                            wind_gust_mph=fc.get("wind_gust_mph"),
                            wind_dir=fc.get("wind_dir"),
                            pressure_mb=fc.get("pressure_mb"),
                            precip_prob=fc.get("precip_prob"),
                            precip_in=fc.get("precip_in"),
                            cloud_cover=fc.get("cloud_cover"),
                            weather_code=fc.get("weather_code"))
                    collected += 1
                    self.notify(f"[{loc['short']}] {WEATHER_MODELS[mk]['name']}: "
                               f"{len(fcs)}h forecast")
                else:
                    self.notify(f"[{loc['short']}] {mk}: FAILED")
                time.sleep(0.5)

            # Tempest BetterForecast (per-station, already localized)
            bf = self.tempest.get_better_forecast_hourly(loc["tempest_station"])
            if bf:
                for fc in bf:
                    self.db.insert_forecast(
                        loc_key, "tempest_bf", fc["issued_at"], fc["valid_at"],
                        fc["lead_hours"],
                        temp_f=fc.get("temp_f"), humidity=fc.get("humidity"),
                        dewpoint_f=fc.get("dewpoint_f"),
                        wind_mph=fc.get("wind_mph"),
                        wind_gust_mph=fc.get("wind_gust_mph"),
                        wind_dir=fc.get("wind_dir"),
                        pressure_mb=fc.get("pressure_mb"),
                        precip_prob=fc.get("precip_prob"),
                        precip_in=fc.get("precip_in"),
                        cloud_cover=fc.get("cloud_cover"),
                        weather_code=fc.get("weather_code"))
                collected += 1
                self.notify(f"[{loc['short']}] Tempest BetterForecast: {len(bf)}h")
            else:
                self.notify(f"[{loc['short']}] tempest_bf: FAILED")

            self.notify(f"[{loc['short']}] {collected}/{len(WEATHER_MODELS)} models collected")

    # ── Ensemble Generation ───────────────────────────────────────────────

    def _compute_bias_correction(self, loc_key: str, model_fcs_now: dict) -> dict:
        """Compare current Tempest reading to what models predicted for NOW.

        Returns a bias dict: {variable: error_degrees} where positive means
        models are underpredicting (reality is warmer/wetter/windier).

        Also logs per-model errors to bias_log for ML feedback learning.
        """
        obs = self.current_obs.get(loc_key)
        if not obs:
            return {}

        bias = {}
        per_model = {}
        ensemble_preds = {}

        for variable in ("temp_f", "humidity", "wind_mph"):
            obs_val = obs.get(variable)
            if obs_val is None:
                continue

            # What did each model predict for this hour?
            model_preds = []
            for mk, fc in model_fcs_now.items():
                val = fc.get(variable)
                if val is not None:
                    model_preds.append(val)
                    # Track per-model error for temp (primary variable)
                    if variable == "temp_f":
                        if mk not in per_model:
                            per_model[mk] = {}
                        per_model[mk]["temp_f"] = val
                        per_model[mk]["error"] = round(obs_val - val, 2)

            if not model_preds:
                continue

            model_avg = sum(model_preds) / len(model_preds)
            error = obs_val - model_avg
            bias[variable] = error
            ensemble_preds[variable] = round(model_avg, 1)

        # Log to bias_log for ML feedback
        if bias:
            ts = datetime.now(timezone.utc).isoformat()
            self.db.insert_bias(
                loc_key, ts,
                {"temp_f": obs.get("temp_f"), "humidity": obs.get("humidity"),
                 "wind_mph": obs.get("wind_mph"), "pressure_mb": obs.get("pressure_mb")},
                ensemble_preds,
                per_model,
            )

            parts = []
            if "temp_f" in bias:
                parts.append(f"temp {bias['temp_f']:+.1f}°F")
                # Show which model was worst
                if per_model:
                    worst = max(per_model.items(), key=lambda x: abs(x[1].get("error", 0)))
                    best = min(per_model.items(), key=lambda x: abs(x[1].get("error", 0)))
                    parts.append(f"worst={worst[0]}({worst[1].get('error',0):+.1f}°)")
                    parts.append(f"best={best[0]}({best[1].get('error',0):+.1f}°)")
            if "humidity" in bias:
                parts.append(f"RH {bias['humidity']:+.1f}%")
            if "wind_mph" in bias:
                parts.append(f"wind {bias['wind_mph']:+.1f}mph")
            self.notify(f"[{LOCATIONS[loc_key]['short']}] Bias: {', '.join(parts)}")

        return bias

    def generate_ensemble(self):
        """Generate ML ensemble predictions with real-time bias correction.

        The bias correction works like operational MOS (Model Output Statistics):
        1. Find the forecast hour closest to NOW
        2. Compare that prediction to the live Tempest reading
        3. Apply the error as a decaying correction to future hours
        4. Decay: full correction at lead=0, tapering to zero by hour 24
        """
        issued_at = datetime.now(timezone.utc).isoformat()
        now = datetime.now()

        for loc_key, loc in LOCATIONS.items():
            latest = self.db.get_latest_forecasts(loc_key)
            if not latest:
                self.notify(f"[{loc['short']}] No forecast data for ensemble")
                continue

            # Group by valid_at
            by_valid = defaultdict(dict)
            for fc in latest:
                by_valid[fc["valid_at"]][fc["model"]] = fc

            sorted_hours = sorted(by_valid.items())

            # Find the forecast hour CLOSEST to right now for bias calc
            bias = {}
            if sorted_hours:
                closest_valid = None
                closest_fcs = None
                min_delta = float("inf")
                for valid_at, fcs in sorted_hours:
                    try:
                        vdt = datetime.fromisoformat(valid_at)
                        delta = abs((vdt - now).total_seconds())
                        if delta < min_delta:
                            min_delta = delta
                            closest_valid = valid_at
                            closest_fcs = fcs
                    except:
                        pass
                if closest_fcs:
                    bias = self._compute_bias_correction(loc_key, closest_fcs)

            count = 0
            for valid_at, model_fcs in sorted_hours:
                lead = list(model_fcs.values())[0].get("lead_hours", 0)
                preds = self.ml.predict_hour(loc_key, model_fcs, lead)

                if "temp_f" not in preds:
                    continue

                # ── Apply bias correction with exponential decay ──
                # Full correction at lead=0, tapering to zero by hour 24
                decay = max(0, 1.0 - (lead / 24.0)) ** 1.5

                kw = {
                    "temp_f": preds["temp_f"]["value"],
                    "confidence": round(preds["temp_f"]["confidence"], 1),
                }

                # Apply bias to predicted variables
                for variable in ("temp_f", "humidity", "wind_mph"):
                    if variable in preds and variable in bias:
                        raw_val = preds[variable]["value"]
                        correction = bias[variable] * decay
                        corrected = round(raw_val + correction, 1)

                        # Clamp to reasonable ranges
                        if variable == "humidity":
                            corrected = max(0, min(100, corrected))
                        elif variable == "wind_mph":
                            corrected = max(0, corrected)

                        kw[variable] = corrected

                        # Adjust confidence: reduce if bias was large
                        if variable == "temp_f":
                            bias_penalty = min(20, abs(bias[variable]) * 2)
                            kw["confidence"] = round(max(10, kw["confidence"] - bias_penalty * decay), 1)

                if "precip_prob" in preds:
                    kw["precip_prob"] = preds["precip_prob"]["value"]

                # Mark method as bias-corrected
                method = preds["temp_f"].get("method", "weighted_avg")
                if bias and decay > 0.05:
                    method += "+bias_corrected"

                # Pass through fields we don't predict
                for src in ("ecmwf", "gfs", "hrrr", "icon"):
                    if src in model_fcs:
                        for field in ("cloud_cover", "weather_code", "pressure_mb",
                                      "dewpoint_f", "wind_gust_mph"):
                            if field not in kw and model_fcs[src].get(field) is not None:
                                kw[field] = model_fcs[src][field]
                        break

                self.db.insert_ensemble(loc_key, issued_at, valid_at, lead,
                                        method, **kw)
                count += 1

            self.notify(f"[{loc['short']}] Ensemble: {count} hours "
                       f"({self.ml.has_trained_models(loc_key) and 'ML' or 'weighted avg'}"
                       f"{', bias-corrected' if bias else ''})")

    # ── NWS ───────────────────────────────────────────────────────────────

    def collect_alerts(self):
        """Pull NWS alerts for both locations."""
        for loc_key, loc in LOCATIONS.items():
            alerts = self.nws.get_alerts(loc["lat"], loc["lon"])
            self.alerts[loc_key] = alerts
            if alerts:
                self.notify(f"[{loc['short']}] ⚠ {len(alerts)} NWS alert(s): "
                           f"{alerts[0]['event']}")
            else:
                self.notify(f"[{loc['short']}] No active NWS alerts")

    def collect_discussion(self):
        """Pull latest AFD from GYX."""
        self.nws_discussion = self.nws.get_forecast_discussion("GYX")
        if self.nws_discussion:
            self.notify("[NWS] Forecast discussion updated")

    # ── Backfill ──────────────────────────────────────────────────────────

    def backfill_observations(self, days: int = 14):
        """Pull historical Tempest data to seed training DB."""
        for loc_key, loc in LOCATIONS.items():
            self.notify(f"[{loc['short']}] Backfilling {days} days of Tempest obs...")
            history = self.tempest.get_history(loc["tempest_station"], days)
            count = 0
            for obs in history:
                ts = obs.pop("timestamp")
                self.db.insert_observation(loc_key, ts, "tempest", **obs)
                count += 1
            self.notify(f"[{loc['short']}] Backfilled {count} observations")

    def backfill_forecasts(self, days: int = 14):
        """Pull historical model forecasts using the Historical Forecast API.
        Each model gets its own actual prediction data (not the same archive)."""
        end = datetime.now().strftime("%Y-%m-%d")
        start = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")

        model_params = {
            "gfs": "gfs_seamless", "hrrr": "hrrr_conus",
            "ecmwf": "ecmwf_ifs025", "icon": "icon_seamless",
            "gem": "gem_seamless", "jma": "jma_seamless",
        }
        all_models = ",".join(model_params.values())

        for loc_key, loc in LOCATIONS.items():
            self.notify(f"[{loc['short']}] Backfilling {days}-day model forecasts...")
            try:
                import requests as req
                r = req.get(
                    "https://historical-forecast-api.open-meteo.com/v1/forecast",
                    params={
                        "latitude": loc["lat"], "longitude": loc["lon"],
                        "hourly": "temperature_2m,relative_humidity_2m,dew_point_2m,"
                                  "wind_speed_10m,wind_gusts_10m,wind_direction_10m,"
                                  "pressure_msl,precipitation,cloud_cover,weather_code",
                        "temperature_unit": "fahrenheit",
                        "wind_speed_unit": "mph",
                        "precipitation_unit": "inch",
                        "start_date": start, "end_date": end,
                        "models": all_models,
                        "timezone": "America/New_York",
                    }, timeout=30)
                if r.status_code != 200:
                    self.notify(f"[{loc['short']}] Historical forecast API: HTTP {r.status_code}")
                    continue

                hourly = r.json().get("hourly", {})
                times = hourly.get("time", [])
                n = len(times)
                issued = f"{start}T00:00:00"

                for our_key, suffix in model_params.items():
                    count = 0
                    for i in range(n):
                        valid = times[i]
                        try:
                            vdt = datetime.fromisoformat(valid)
                            sdt = datetime.fromisoformat(start)
                            lead = max(0, int((vdt - sdt).total_seconds() / 3600))
                        except:
                            lead = i

                        def _g(var):
                            col = f"{var}_{suffix}"
                            arr = hourly.get(col, hourly.get(var, []))
                            return arr[i] if i < len(arr) else None

                        self.db.insert_forecast(
                            loc_key, our_key, issued, valid, lead,
                            temp_f=_g("temperature_2m"),
                            humidity=_g("relative_humidity_2m"),
                            dewpoint_f=_g("dew_point_2m"),
                            wind_mph=_g("wind_speed_10m"),
                            wind_gust_mph=_g("wind_gusts_10m"),
                            wind_dir=_g("wind_direction_10m"),
                            pressure_mb=_g("pressure_msl"),
                            precip_in=_g("precipitation"),
                            cloud_cover=_g("cloud_cover"),
                            weather_code=_g("weather_code"))
                        count += 1
                    self.notify(f"[{loc['short']}] {our_key}: {count} forecast hours")
            except Exception as e:
                self.notify(f"[{loc['short']}] Forecast backfill error: {e}")
            time.sleep(1)

    # ── Retraining ────────────────────────────────────────────────────────

    def retrain(self):
        """Retrain ML models for both locations."""
        for loc_key, loc in LOCATIONS.items():
            self.notify(f"[{loc['short']}] Retraining ML models...")
            results = self.ml.train_all(loc_key)
            for var, buckets in results.items():
                for bucket, info in buckets.items():
                    if info.get("status") == "trained":
                        self.notify(
                            f"[{loc['short']}] {var}/{bucket}: "
                            f"MAE={info['mae']}, "
                            f"{info['improvement_pct']:+.1f}% vs {info['best_individual']}")
                    else:
                        self.notify(
                            f"[{loc['short']}] {var}/{bucket}: "
                            f"need more data ({info.get('n_samples', 0)} samples)")

    # ── Run Cycle ─────────────────────────────────────────────────────────

    def run_cycle(self):
        """One complete collection → prediction cycle."""
        try:
            self.notify("━━━ Collection cycle ━━━")
            self.collect_observations()
            self.collect_forecasts()
            self.generate_ensemble()
            self.collect_alerts()
            # Push data to HA sensors for remote access
            if self.ha_publisher:
                self.ha_publisher.publish_all(self)
            self.notify("━━━ Cycle complete ━━━")
        except Exception as e:
            self.notify(f"[ERROR] Cycle failed: {e}")
            log.error(traceback.format_exc())

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        self.notify("WeatherOracle started")

    def stop(self):
        self._running = False
        self.notify("WeatherOracle stopped")

    def _loop(self):
        self.run_cycle()
        self.collect_discussion()

        interval = self.config.get("collection_interval_min", 15) * 60
        retrain_interval = self.config.get("retrain_interval_hours", 6) * 3600
        last_retrain = 0
        last_discussion = time.time()

        while self._running:
            time.sleep(interval)
            if not self._running:
                break
            self.run_cycle()

            # Periodic retraining
            if time.time() - last_retrain >= retrain_interval:
                self.retrain()
                last_retrain = time.time()

            # Refresh AFD every 4 hours
            if time.time() - last_discussion >= 14400:
                self.collect_discussion()
                last_discussion = time.time()

    # ── Getters for GUI ───────────────────────────────────────────────────

    def get_current(self, location: str) -> Optional[dict]:
        return self.current_obs.get(location) or self.db.get_latest_obs(location)

    def get_crosscheck(self, location: str) -> dict:
        return self.crosscheck.get(location, {})

    def get_forecast(self, location: str) -> list:
        return self.db.get_ensemble_forecast(location)

    def get_raw_forecasts(self, location: str) -> list:
        return self.db.get_latest_forecasts(location)

    def get_alerts_for(self, location: str) -> list:
        return self.alerts.get(location, [])

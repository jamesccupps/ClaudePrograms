"""Configuration, constants, and location definitions."""

import json
import os
from pathlib import Path

APP_DIR = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB_PATH = APP_DIR / "data" / "weather_oracle.db"
CONFIG_PATH = APP_DIR / "data" / "weather_oracle_config.json"
MODEL_DIR = APP_DIR / "models"

# Ensure dirs exist
(APP_DIR / "data").mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)

# ─── Locations ────────────────────────────────────────────────────────────────

LOCATIONS = {
    "apartment": {
        "name": "Apartment (Biddeford)",
        "short": "APT",
        "tempest_station": 153140,
        "lat": 43.4926,
        "lon": -70.4534,
        "nws_office": "GYX",
        "nws_gridpoint": None,  # auto-discovered on first run
        "color": "#00d4aa",
        "color_dark": "#008f72",
    },
    "occ": {
        "name": "One City Center (Portland)",
        "short": "OCC",
        "tempest_station": 179979,
        "lat": 43.6591,
        "lon": -70.2568,
        "nws_office": "GYX",
        "nws_gridpoint": None,
        "color": "#4a90d9",
        "color_dark": "#2d5f9e",
    },
}

# ─── Open-Meteo Weather Models ───────────────────────────────────────────────

WEATHER_MODELS = {
    "gfs": {
        "name": "GFS (NOAA)",
        "url": "https://api.open-meteo.com/v1/gfs",
        "desc": "Global 0.25°, strong 3-7 day",
        "priority": 1.5,
    },
    "hrrr": {
        "name": "HRRR (NOAA)",
        "url": "https://api.open-meteo.com/v1/gfs",
        "desc": "High-res rapid refresh, best <18hr",
        "priority": 3.0,  # heavily weighted short-term
    },
    "ecmwf": {
        "name": "ECMWF IFS",
        "url": "https://api.open-meteo.com/v1/ecmwf",
        "desc": "European model, best overall skill",
        "priority": 2.5,
    },
    "icon": {
        "name": "ICON (DWD)",
        "url": "https://api.open-meteo.com/v1/dwd-icon",
        "desc": "German model, good mesoscale",
        "priority": 1.5,
    },
    "gem": {
        "name": "GEM (Canada)",
        "url": "https://api.open-meteo.com/v1/gem",
        "desc": "Canadian model, relevant for NE",
        "priority": 1.2,
    },
    "jma": {
        "name": "JMA (Japan)",
        "url": "https://api.open-meteo.com/v1/jma",
        "desc": "Japanese model, independent view",
        "priority": 1.0,
    },
    "tempest_bf": {
        "name": "Tempest BetterForecast",
        "url": None,  # Not Open-Meteo — collected via Tempest API
        "desc": "Tempest ML-enhanced local forecast",
        "priority": 2.5,  # High weight — already localized to your station
    },
}

# ─── Forecast Variables ───────────────────────────────────────────────────────

FORECAST_VARS = [
    "temperature_2m", "relative_humidity_2m", "dew_point_2m",
    "apparent_temperature", "precipitation_probability", "precipitation",
    "wind_speed_10m", "wind_gusts_10m", "wind_direction_10m",
    "cloud_cover", "pressure_msl", "weather_code",
]

HOURLY_PARAMS = ",".join(FORECAST_VARS)

# ─── WMO Weather Codes ───────────────────────────────────────────────────────

WMO_CODES = {
    0: "Clear", 1: "Mainly Clear", 2: "Partly Cloudy", 3: "Overcast",
    45: "Fog", 48: "Rime Fog",
    51: "Lt Drizzle", 53: "Drizzle", 55: "Hvy Drizzle",
    56: "Frzg Drizzle", 57: "Hvy Frzg Drizzle",
    61: "Lt Rain", 63: "Rain", 65: "Heavy Rain",
    66: "Frzg Rain", 67: "Hvy Frzg Rain",
    71: "Lt Snow", 73: "Snow", 75: "Heavy Snow", 77: "Snow Grains",
    80: "Lt Showers", 81: "Showers", 82: "Heavy Showers",
    85: "Lt Snow Shwrs", 86: "Snow Showers",
    95: "Thunderstorm", 96: "T-Storm + Hail", 99: "Severe T-Storm",
}

WMO_ICONS = {
    0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️",
    45: "🌫️", 48: "🌫️",
    51: "🌦️", 53: "🌧️", 55: "🌧️", 56: "🌧️", 57: "🌧️",
    61: "🌦️", 63: "🌧️", 65: "🌧️", 66: "🌧️", 67: "🌧️",
    71: "🌨️", 73: "❄️", 75: "❄️", 77: "❄️",
    80: "🌦️", 81: "🌧️", 82: "⛈️",
    85: "🌨️", 86: "🌨️",
    95: "⛈️", 96: "⛈️", 99: "⛈️",
}

# ─── Default Config ───────────────────────────────────────────────────────────

DEFAULT_CONFIG = {
    "tempest_api_token": "",
    "ha_url": "http://192.168.12.197:8123",
    "ha_token": "",
    "collection_interval_min": 15,
    "retrain_interval_hours": 6,
    "min_training_samples": 48,
    "forecast_hours": 72,
    "yolink_temp_entity": "sensor.clifford_st_sensors_temperature",
    "yolink_humidity_entity": "sensor.clifford_st_sensors_humidity",
    "outdoor_temp_entity": "sensor.outdoor_temp_sensor_temperature",
    "outdoor_humidity_entity": "sensor.outdoor_temp_sensor_humidity",
    "avg_outdoor_temp_entity": "sensor.average_outdoor_temp",
    "avg_outdoor_humidity_entity": "sensor.average_outdoor_humidity",
}


def load_config() -> dict:
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            saved = json.load(f)
        return {**DEFAULT_CONFIG, **saved}
    return dict(DEFAULT_CONFIG)


def save_config(cfg: dict):
    CONFIG_PATH.parent.mkdir(exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)

"""Gradient-boosted ensemble that learns each weather model's bias
for specific microlocations over time."""

import logging
import pickle
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Optional

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_absolute_error, mean_squared_error

from core.config import WEATHER_MODELS, MODEL_DIR

log = logging.getLogger("WeatherOracle.ml")

# Lead-time buckets for separate models
LEAD_BUCKETS = [
    ("0-6h", 0, 6),
    ("6-18h", 6, 18),
    ("18-48h", 18, 48),
    ("48-72h", 48, 72),
]

TRAINABLE_VARS = ["temp_f", "humidity", "wind_mph"]

# Default weights when no ML model is available yet
FALLBACK_WEIGHTS = {
    "hrrr":       {"short": 3.0, "long": 1.0},
    "tempest_bf": {"short": 2.8, "long": 2.0},  # Already localized to station
    "ecmwf":      {"short": 2.0, "long": 2.5},
    "gfs":        {"short": 1.2, "long": 2.0},
    "icon":       {"short": 1.5, "long": 1.5},
    "gem":        {"short": 1.0, "long": 1.5},
    "jma":        {"short": 0.8, "long": 1.0},
}


class MLEngine:
    """Per-location, per-variable, per-lead-bucket gradient boosted ensemble."""

    def __init__(self, db):
        self.db = db
        self.models = {}       # {(location, variable, bucket): GBR}
        self.feature_names = {}
        self._load_saved()

    def _model_path(self, location, variable, bucket):
        return MODEL_DIR / f"{location}_{variable}_{bucket}.pkl"

    def _load_saved(self):
        """Load previously trained models from disk."""
        for p in MODEL_DIR.glob("*.pkl"):
            try:
                with open(p, "rb") as f:
                    saved = pickle.load(f)
                key = tuple(saved["key"])
                self.models[key] = saved["model"]
                self.feature_names[key] = saved["features"]
                log.info("Loaded model: %s", key)
            except Exception as e:
                log.warning("Failed to load %s: %s", p.name, e)

    def has_trained_models(self, location: str) -> bool:
        return any(k[0] == location for k in self.models)

    def get_model_count(self, location: str) -> int:
        return sum(1 for k in self.models if k[0] == location)

    # ── Training ──────────────────────────────────────────────────────────

    def train_all(self, location: str) -> dict:
        """Train models for all variables and lead buckets at a location."""
        results = {}
        for variable in TRAINABLE_VARS:
            results[variable] = self.train_variable(location, variable)
        return results

    def train_variable(self, location: str, variable: str) -> dict:
        """Train models for one variable across all lead-time buckets."""
        results = {}
        for bucket_name, lead_min, lead_max in LEAD_BUCKETS:
            X, y, fnames = self.db.get_training_data(
                location, variable, (lead_min, lead_max))

            if X is None or len(X) < 20:
                results[bucket_name] = {
                    "status": "insufficient_data",
                    "n_samples": 0 if X is None else len(X),
                }
                continue

            gbr = GradientBoostingRegressor(
                n_estimators=150,
                max_depth=4,
                learning_rate=0.08,
                subsample=0.8,
                min_samples_leaf=max(3, len(X) // 50),
                random_state=42,
            )

            # Cross-validate
            n_splits = min(5, max(2, len(X) // 10))
            try:
                cv = cross_val_score(gbr, X, y, cv=n_splits,
                                     scoring="neg_mean_absolute_error")
                cv_mae = round(-cv.mean(), 3)
            except:
                cv_mae = None

            # Full fit
            gbr.fit(X, y)
            preds = gbr.predict(X)
            mae = mean_absolute_error(y, preds)
            rmse = np.sqrt(mean_squared_error(y, preds))

            # Best individual model comparison
            best_ind_mae = float("inf")
            best_ind_name = "none"
            for fn in fnames:
                if fn.endswith(f"_{variable}"):
                    mname = fn.replace(f"_{variable}", "")
                    col = fnames.index(fn)
                    vals = X[:, col]
                    m = mean_absolute_error(y, vals)
                    if m < best_ind_mae:
                        best_ind_mae = m
                        best_ind_name = mname

            improvement = ((best_ind_mae - mae) / best_ind_mae * 100
                           if best_ind_mae > 0 else 0)

            # Save
            key = (location, variable, bucket_name)
            self.models[key] = gbr
            self.feature_names[key] = fnames
            with open(self._model_path(location, variable, bucket_name), "wb") as f:
                pickle.dump({"key": key, "model": gbr, "features": fnames}, f)

            # Feature importances
            top = sorted(zip(fnames, gbr.feature_importances_),
                         key=lambda x: -x[1])[:5]

            results[bucket_name] = {
                "status": "trained",
                "n_samples": len(X),
                "mae": round(mae, 3),
                "rmse": round(rmse, 3),
                "cv_mae": cv_mae,
                "best_individual": best_ind_name,
                "best_individual_mae": round(best_ind_mae, 3),
                "improvement_pct": round(improvement, 1),
                "top_features": top,
            }

            # Log to DB
            try:
                self.db.conn.execute("""
                    INSERT INTO training_log
                    (location, variable, bucket, timestamp, n_samples,
                     cv_mae, ensemble_mae, best_individual,
                     best_individual_mae, improvement_pct)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                """, (location, variable, bucket_name,
                      datetime.now(timezone.utc).isoformat(),
                      len(X), cv_mae, round(mae, 3),
                      best_ind_name, round(best_ind_mae, 3),
                      round(improvement, 1)))
                self.db.conn.commit()
            except:
                pass

            log.info("Trained %s/%s/%s: MAE=%.3f vs best %.3f (%+.1f%%)",
                     location, variable, bucket_name,
                     mae, best_ind_mae, improvement)

        return results

    # ── Prediction ────────────────────────────────────────────────────────

    def _get_bucket(self, lead_hours: int) -> str:
        if lead_hours <= 6: return "0-6h"
        if lead_hours <= 18: return "6-18h"
        if lead_hours <= 48: return "18-48h"
        return "48-72h"

    def predict(self, location: str, variable: str,
                model_forecasts: dict, lead_hours: int) -> Optional[dict]:
        """Predict using trained ML model or fall back to weighted average.

        model_forecasts: {model_key: {field: value, ...}, ...}
        """
        bucket = self._get_bucket(lead_hours)
        key = (location, variable, bucket)

        # Collect raw model values
        model_vals = []
        for mk in WEATHER_MODELS:
            v = model_forecasts.get(mk, {}).get(variable)
            if v is not None:
                model_vals.append((mk, v))

        if len(model_vals) < 2:
            return None

        vals_only = [v for _, v in model_vals]
        spread = max(vals_only) - min(vals_only)

        # Get recent bias data for dynamic adjustments
        bias_features = None
        try:
            bias_features = self.db.get_bias_features(location, variable)
        except:
            pass

        # ── ML path ──
        if key in self.models and key in self.feature_names:
            fnames = self.feature_names[key]
            features = {}
            for mk in WEATHER_MODELS:
                mf = model_forecasts.get(mk, {})
                features[f"{mk}_{variable}"] = mf.get(variable)
                features[f"{mk}_lead_hours"] = lead_hours

            now = datetime.now()
            features["hour_of_day"] = now.hour
            features["day_of_year"] = now.timetuple().tm_yday
            features["month"] = now.month

            median = float(np.median(vals_only))
            row = [features.get(fn, median) for fn in fnames]
            row = [median if v is None else v for v in row]

            try:
                pred = float(self.models[key].predict([row])[0])

                # Post-ML bias trend correction: if the ensemble has been
                # consistently off in one direction recently, nudge the
                # prediction to compensate
                if bias_features and variable == "temp_f":
                    recent_bias = bias_features.get("ensemble_recent_bias_temp_f", 0)
                    n_samples = bias_features.get("bias_sample_count", 0)
                    if n_samples >= 3 and abs(recent_bias) > 1.0:
                        # Apply a fraction of the recent bias trend
                        # More samples = more trust in the correction
                        trust = min(0.5, n_samples / 20.0)
                        pred += recent_bias * trust

                confidence = max(0, min(100, 100 - spread * 4))
                return {
                    "value": round(pred, 1),
                    "confidence": round(confidence, 1),
                    "method": "ml_ensemble",
                    "bucket": bucket,
                    "n_models": len(model_vals),
                    "spread": round(spread, 1),
                }
            except Exception as e:
                log.error("ML predict error: %s", e)

        # ── Weighted average fallback with dynamic weights ──
        # Start with base weights, then adjust by recent per-model accuracy
        is_short = lead_hours <= 18
        wkey = "short" if is_short else "long"
        dynamic_weights = {}
        for mk in WEATHER_MODELS:
            base_w = FALLBACK_WEIGHTS.get(mk, {"short": 1, "long": 1})[wkey]
            # If we have bias data, reward models that have been accurate
            # and penalize those that have been consistently wrong
            if bias_features and variable == "temp_f":
                abs_err = bias_features.get(f"{mk}_recent_abs_error")
                if abs_err is not None:
                    # Models with <2°F avg error get boosted, >5°F get penalized
                    accuracy_factor = max(0.3, min(2.0, 3.0 / max(abs_err, 0.5)))
                    dynamic_weights[mk] = base_w * accuracy_factor
                else:
                    dynamic_weights[mk] = base_w
            else:
                dynamic_weights[mk] = base_w

        total_w, weighted_sum = 0, 0
        for mk, val in model_vals:
            w = dynamic_weights.get(mk, 1.0)
            weighted_sum += val * w
            total_w += w

        pred = weighted_sum / total_w if total_w else np.mean(vals_only)

        # Apply bias trend correction to weighted avg too
        if bias_features and variable == "temp_f":
            recent_bias = bias_features.get("ensemble_recent_bias_temp_f", 0)
            n_samples = bias_features.get("bias_sample_count", 0)
            if n_samples >= 3 and abs(recent_bias) > 1.0:
                trust = min(0.4, n_samples / 25.0)
                pred += recent_bias * trust

        confidence = max(0, min(100, 100 - spread * 4))

        return {
            "value": round(pred, 1),
            "confidence": round(confidence, 1),
            "method": "weighted_avg" + ("+bias_adjusted" if bias_features else ""),
            "bucket": bucket,
            "n_models": len(model_vals),
            "spread": round(spread, 1),
        }

    def predict_hour(self, location: str, model_forecasts: dict,
                     lead_hours: int) -> dict:
        """Predict all variables for one forecast hour."""
        result = {}
        for var in TRAINABLE_VARS:
            p = self.predict(location, var, model_forecasts, lead_hours)
            if p:
                result[var] = p
        # Precip prob: simple average
        probs = [model_forecasts.get(mk, {}).get("precip_prob")
                 for mk in WEATHER_MODELS]
        probs = [p for p in probs if p is not None]
        if probs:
            result["precip_prob"] = {"value": round(sum(probs)/len(probs), 0),
                                     "method": "model_avg"}
        return result

    # ── Accuracy ──────────────────────────────────────────────────────────

    def compute_accuracy(self, location: str, days: int = 7) -> dict:
        """Compute accuracy metrics for each model + ensemble over last N days."""
        lookback = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        obs_list = self.db.get_observations(location, since=lookback, source="tempest")
        if not obs_list:
            return {}

        results = {}
        all_models = list(WEATHER_MODELS.keys()) + ["ensemble"]

        for variable in TRAINABLE_VARS:
            results[variable] = {}
            for model_key in all_models:
                errors = []
                for ob in obs_list:
                    ts = ob["timestamp"]
                    ob_val = ob.get(variable)
                    if ob_val is None:
                        continue

                    try:
                        ob_dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                    except:
                        continue
                    ts_lo = (ob_dt - timedelta(minutes=30)).isoformat()
                    ts_hi = (ob_dt + timedelta(minutes=30)).isoformat()

                    with self.db.lock:
                        if model_key == "ensemble":
                            rows = self.db.conn.execute("""
                                SELECT temp_f, humidity, wind_mph
                                FROM ensemble_forecasts
                                WHERE location=? AND valid_at >= ? AND valid_at <= ?
                                LIMIT 1
                            """, (location, ts_lo, ts_hi)).fetchall()
                        else:
                            rows = self.db.conn.execute("""
                                SELECT temp_f, humidity, wind_mph
                                FROM forecasts
                                WHERE location=? AND model=?
                                  AND valid_at >= ? AND valid_at <= ?
                                ORDER BY lead_hours ASC LIMIT 1
                            """, (location, model_key, ts_lo, ts_hi)).fetchall()

                    if rows:
                        pred = rows[0][variable]
                        if pred is not None:
                            errors.append(pred - ob_val)

                if errors:
                    e = np.array(errors)
                    results[variable][model_key] = {
                        "mae": round(float(np.mean(np.abs(e))), 2),
                        "rmse": round(float(np.sqrt(np.mean(e**2))), 2),
                        "bias": round(float(np.mean(e)), 2),
                        "n": len(errors),
                    }
        return results

    def get_training_summary(self, location: str) -> list:
        """Get recent training log entries."""
        with self.db.lock:
            return [dict(r) for r in self.db.conn.execute("""
                SELECT * FROM training_log
                WHERE location=?
                ORDER BY timestamp DESC LIMIT 50
            """, (location,)).fetchall()]

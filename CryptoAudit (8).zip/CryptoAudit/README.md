# CryptoAudit ML — AI-Powered Encryption Analyzer

Companion tool for NetSentinel. Analyzes encrypted network traffic using machine learning to detect weak, fake, or broken encryption — then actually cracks it and proves it.

## Quick Start
1. Unzip `CryptoAudit/` next to NetSentinel
2. Double-click `CryptoAudit.bat`
3. That's it — models auto-train on first launch

## What It Does

### ML Classification (5-model ensemble)
Random Forest (500 trees) + Gradient Boosting (200 trees) + Autoencoder (anomaly detection) + Isolation Forest — trained on 37 statistical features including entropy, chi-square, serial correlation, block patterns, n-grams, XOR IoC, FFT periodicity. Training data includes real TLS record structures so the autoencoder doesn't false-positive on legitimate protocol traffic.

### Protocol Detection
Identifies TLS (all versions), SSH, and WireGuard by their actual byte signatures. Properly encrypted protocol traffic gets classified STRONG regardless of what the ML models say — but still gets scanned for PAN leakage and sensitive string extraction. If decryption methods find something real despite the protocol header, the classification gets upgraded back to WEAK.

### Decryption Engine (13 methods)
| Method | What it cracks | Key output |
|--------|---------------|------------|
| XOR Key Recovery | XOR with 1-32 byte keys | Recovered key + plaintext |
| Caesar/Shift | Byte shift ciphers (all 256) | Shift value + plaintext |
| ROT13 / ROT47 | Letter/ASCII rotation | Plaintext |
| Vigenere Crack | Polyalphabetic ciphers | Keyword + plaintext |
| Base64 Decode | Base64 "encryption" | Decoded content |
| Hex Decode | Hex "encryption" | Decoded content |
| URL Decode | URL-encoded data | Decoded content |
| Multi-Layer Peel | Nested encoding (b64(hex(data))) | Layer chain + content |
| ECB Block Analysis | AES-ECB mode | Block repetition map |
| Known-Plaintext | XOR/stream ciphers with known crib | Recovered key |
| Pattern Detection | Custom repeating ciphers | Pattern + autocorrelation |
| Entropy Windowing | Mixed encrypted/plaintext files | Section boundaries |
| String Extraction | Plaintext leakage in encrypted streams | Sensitive data items |

### Key Vault (Persistent)
Every recovered key is saved to `feedback/key_vault.json` and persists across sessions.
- **Cross-stream attack:** After analyzing all streams, every harvested key is tried against every uncracked stream (including sub-key factors)
- **Cross-capture detection:** Run captures on Monday and Wednesday — if the same device uses the same XOR key both times, it flags CROSS-CAPTURE REUSE with both capture filenames
- **Cross-mode:** Keys from PCAP analysis are available in Live Capture and Payload Analysis, and vice versa
- Dashboard shows key vault count and reuse stats
- Clear from Settings when needed

### AI Validation + Feedback Loop
- Ollama integration (qwen2.5:14b or any model) validates decryption output
- Heuristic fallback when Ollama isn't running
- Every analysis feeds back to retrain ML models
- Method reliability tracking on the Dashboard

## Tabs
| Tab | Purpose |
|-----|---------|
| Dashboard | Model status, accuracy, key vault count, method reliability |
| PCAP Analysis | Load .pcap/.pcapng files with progress bar + streaming reader |
| Live Capture | Real-time packet capture with continuous analysis (needs admin) |
| Payload Analysis | Analyze any file/text/hex/base64 with known-plaintext crib field |
| Training | Train from synthetic data, PCAPs, or accumulated feedback |
| Settings | Ollama URL/model, auto-decrypt/validate, clear feedback/keys |

## PCAP Analysis Phases
1. **Load** — Streams packets via PcapReader (low memory, progress bar)
2. **Analyze** — ML classification + decryption on each stream (incremental display)
3. **Cross-Stream** — Harvested keys tried against uncracked streams

## Input Formats
PCAP/PCAPNG, raw binary, hex (spaces/colons/0x), base64, JSON (NetSentinel exports), CSV, .enc/.encrypted/.cipher/.dat/.txt/.key/.log files, clipboard paste

## Ports Monitored (40+)
HTTPS (443, 8443), HTTP (80, 8080), Email (993, 995, 465), POS (5696, 2050, 20000, 4430, 9100, 5555), Databases (MySQL 3306, PostgreSQL 5432, MSSQL 1433, Oracle 1521, MongoDB 27017, Redis 6379), Remote (SSH 22, RDP 3389, VNC 5900), LDAP/Kerberos (636, 389, 88), IoT (MQTT-TLS 8883, AMQP-TLS 5671, BACnet 47808), VPN (IKE 500, IPSec 4500, OpenVPN 1194, WireGuard 51820), API (9443, 6443, 2376)

## Folder Structure
```
CryptoAudit/
├── crypto_audit.py          <- Main application (2,700+ lines)
├── CryptoAudit.bat          <- Windows launcher
├── README.md
├── models/                  <- Trained ML models (auto-generated)
├── feedback/
│   ├── key_vault.json       <- Persistent key vault (cross-session)
│   ├── method_stats.json    <- Decryption method reliability stats
│   └── samples/             <- Auto-labeled training samples
├── logs/                    <- Rotating debug logs (5MB x 5)
├── exports/                 <- Session reports (JSON)
└── debug/                   <- Debug snapshots (ZIP)
```

## Troubleshooting
1. Click **Export Debug** -> sends ZIP from debug/ folder
2. Click **Export Session** -> sends JSON from exports/ folder
3. Check logs/crypto_audit.log for errors
4. Send both to Claude for analysis

## Dependencies
```
pip install numpy scikit-learn scipy joblib scapy
```

## Ollama (Optional)
```
ollama run qwen2.5:14b
```
Configure URL/model in Settings tab. Works without Ollama using heuristic validation.

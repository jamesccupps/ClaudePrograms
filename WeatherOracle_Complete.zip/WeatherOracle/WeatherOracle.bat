@echo off
title WeatherOracle — Hyperlocal ML Weather Prediction
cd /d "%~dp0"

:: Find real Python via py launcher
set "PYTHON="

py -3 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=py -3"
    goto :found
)

:: Direct path to James's Python 3.13
if exist "C:\Users\james\AppData\Local\Programs\Python\Python313\python.exe" (
    set "PYTHON=C:\Users\james\AppData\Local\Programs\Python\Python313\python.exe"
    goto :found
)

echo ERROR: Could not find Python. Install from https://python.org
pause
exit /b 1

:found
echo Using Python:
%PYTHON% -c "import sys; print(sys.executable, f'(Python {sys.version.split()[0]})')"
echo.

:: Always ensure ALL dependencies are installed
%PYTHON% -m pip install --quiet requests scikit-learn numpy 2>nul

:: Verify all three import
%PYTHON% -c "import requests; import sklearn; import numpy; print('All dependencies OK')" 2>nul
if errorlevel 1 (
    echo Installing dependencies...
    %PYTHON% -m pip install --upgrade requests scikit-learn numpy
    if errorlevel 1 (
        echo.
        echo ERROR: pip install failed.
        pause
        exit /b 1
    )
)

:: Final verify
%PYTHON% -c "import requests; import sklearn; import numpy; print('All dependencies OK')"
if errorlevel 1 (
    echo.
    echo ERROR: Dependencies still failing after install.
    echo Your Python: 
    %PYTHON% -c "import sys; print(sys.executable)"
    echo Try manually: [that python path] -m pip install requests scikit-learn numpy
    pause
    exit /b 1
)

:: Launch
echo.
echo Starting WeatherOracle...
%PYTHON% main.py
if errorlevel 1 (
    echo.
    echo WeatherOracle exited with an error.
)
pause

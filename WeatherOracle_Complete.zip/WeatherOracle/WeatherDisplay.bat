@echo off
title WeatherOracle Display
cd /d "%~dp0"

:: Find Python (same logic as main app)
set "PYTHON="
py -3 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=py -3"
    goto :found
)
if exist "C:\Users\james\AppData\Local\Programs\Python\Python313\python.exe" (
    set "PYTHON=C:\Users\james\AppData\Local\Programs\Python\Python313\python.exe"
    goto :found
)
python -c "import sys; exit(0 if 'inkscape' not in sys.executable.lower() else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=python"
    goto :found
)
echo ERROR: Python not found.
pause
exit /b 1

:found
echo Opening WeatherOracle Dashboard in your browser...
%PYTHON% weather_display.py
pause

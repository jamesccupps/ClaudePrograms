"""WeatherFlow Tempest REST API collector."""

import logging
import time
from datetime import datetime, timezone
from typing import Optional

import requests

log = logging.getLogger("WeatherOracle.tempest")


def _c_to_f(c):
    return round(c * 9 / 5 + 32, 1) if c is not None else None


def _mps_to_mph(mps):
    return round(mps * 2.237, 1) if mps is not None else None


def _mm_to_in(mm):
    return round(mm * 0.03937, 3) if mm is not None else None


class TempestCollector:
    """Pull observations and forecasts from WeatherFlow Tempest."""

    BASE = "https://swd.weatherflow.com/swd/rest"

    def __init__(self, token: str):
        self.token = token
        self.session = requests.Session()
        self.session.headers["Accept"] = "application/json"

    def _parse_obs(self, o: dict) -> dict:
        """Convert a single Tempest observation dict to our format."""
        return {
            "temp_f": _c_to_f(o.get("air_temperature")),
            "humidity": o.get("relative_humidity"),
            "dewpoint_f": _c_to_f(o.get("dew_point")),
            "wind_mph": _mps_to_mph(o.get("wind_avg")),
            "wind_gust_mph": _mps_to_mph(o.get("wind_gust")),
            "wind_dir": o.get("wind_direction"),
            "pressure_mb": o.get("sea_level_pressure") or o.get("station_pressure"),
            "precip_in": _mm_to_in(o.get("precip_accum_local_day")),
            "solar_radiation": o.get("solar_radiation"),
            "uv_index": o.get("uv"),
            "feels_like_f": _c_to_f(o.get("feels_like")),
            "wet_bulb_f": _c_to_f(o.get("wet_bulb_temperature")),
            "timestamp": datetime.fromtimestamp(
                o.get("timestamp", 0), tz=timezone.utc
            ).isoformat(),
        }

    def get_current(self, station_id: int) -> Optional[dict]:
        """Latest observation from a Tempest station."""
        try:
            r = self.session.get(
                f"{self.BASE}/observations/station/{station_id}",
                params={"token": self.token}, timeout=15)
            r.raise_for_status()
            obs = r.json().get("obs", [])
            return self._parse_obs(obs[0]) if obs else None
        except Exception as e:
            log.error("Tempest current (station %s): %s", station_id, e)
            return None

    def get_history(self, station_id: int, days_back: int = 30) -> list:
        """Pull historical observations for backfilling."""
        results = []
        try:
            end = int(time.time())
            for d in range(days_back):
                day_start = end - (d + 1) * 86400
                day_end = day_start + 86400
                r = self.session.get(
                    f"{self.BASE}/observations/station/{station_id}",
                    params={"token": self.token,
                            "time_start": day_start, "time_end": day_end},
                    timeout=20)
                if r.status_code != 200:
                    continue
                for o in r.json().get("obs", []):
                    parsed = self._parse_obs(o)
                    # Override precip to per-observation not daily accum
                    parsed["precip_in"] = _mm_to_in(o.get("precip"))
                    results.append(parsed)
                time.sleep(0.3)
            log.info("Tempest history: %d obs from station %s (%d days)",
                     len(results), station_id, days_back)
        except Exception as e:
            log.error("Tempest history error: %s", e)
        return results

    def get_better_forecast(self, station_id: int) -> Optional[dict]:
        """Get Tempest's BetterForecast (their own blended forecast)."""
        try:
            r = self.session.get(
                f"{self.BASE}/better_forecast",
                params={
                    "station_id": station_id, "token": self.token,
                    "units_temp": "f", "units_wind": "mph",
                    "units_pressure": "mb", "units_precip": "in",
                    "units_distance": "mi",
                },
                timeout=15)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log.error("Tempest BetterForecast error: %s", e)
            return None

    def test_connection(self, station_id: int) -> tuple:
        """Test API token + station. Returns (success, message)."""
        obs = self.get_current(station_id)
        if obs:
            return True, f"Connected: {obs['temp_f']}°F, {obs['humidity']}% RH"
        return False, "Could not reach Tempest API — check token"

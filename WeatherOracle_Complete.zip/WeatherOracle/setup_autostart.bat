@echo off
:: ============================================================
:: Auto-Start Setup for WeatherOracle + Stock Oracle
:: Registers both apps to launch automatically on Windows login
:: Run this ONCE as administrator
:: ============================================================

echo ============================================
echo  Auto-Start Setup
echo ============================================
echo.

:: Find Python (same logic as WeatherOracle.bat)
set "PYTHON="
py -3 --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=*" %%i in ('py -3 -c "import sys; print(sys.executable)"') do set "PYTHON=%%i"
    goto :found
)
if exist "C:\Users\james\AppData\Local\Programs\Python\Python313\python.exe" (
    set "PYTHON=C:\Users\james\AppData\Local\Programs\Python\Python313\python.exe"
    goto :found
)
echo ERROR: Could not find Python.
pause
exit /b 1

:found
echo Found Python: %PYTHON%
echo.

:: ── WeatherOracle ────────────────────────────────────────────
set "WO_DIR=%~dp0"
set "WO_SCRIPT=%WO_DIR%main.py"

if not exist "%WO_SCRIPT%" (
    echo WARNING: WeatherOracle main.py not found at %WO_SCRIPT%
    echo Place this script in your WeatherOracle folder.
    echo.
) else (
    echo Registering WeatherOracle...
    schtasks /create /tn "WeatherOracle" /tr "\"%PYTHON%\" \"%WO_SCRIPT%\"" /sc onlogon /rl highest /f /delay 0000:30
    if not errorlevel 1 (
        echo   [OK] WeatherOracle will auto-start 30 seconds after login
    ) else (
        echo   [FAIL] Could not create task. Run this script as Administrator.
    )
    echo.
)

:: ── Stock Oracle ─────────────────────────────────────────────
:: Common locations — adjust if yours is different
set "SO_SCRIPT="
for %%P in (
    "C:\Users\JamesCupps\Downloads\StockOracle\main.py"
    "C:\Users\james\Downloads\StockOracle\main.py"
    "G:\StockOracle\main.py"
    "C:\StockOracle\main.py"
) do (
    if exist %%P (
        set "SO_SCRIPT=%%~P"
        goto :so_found
    )
)

echo Stock Oracle main.py not found in common locations.
echo Enter the full path to Stock Oracle's main.py (or press Enter to skip):
set /p SO_SCRIPT="> "
if "%SO_SCRIPT%"=="" goto :so_skip

:so_found
if exist "%SO_SCRIPT%" (
    echo Registering Stock Oracle...
    for %%F in ("%SO_SCRIPT%") do set "SO_DIR=%%~dpF"
    schtasks /create /tn "StockOracle" /tr "\"%PYTHON%\" \"%SO_SCRIPT%\"" /sc onlogon /rl highest /f /delay 0001:00
    if not errorlevel 1 (
        echo   [OK] Stock Oracle will auto-start 60 seconds after login
    ) else (
        echo   [FAIL] Could not create task. Run this script as Administrator.
    )
) else (
    echo   Stock Oracle path not found: %SO_SCRIPT%
)
echo.

:so_skip

:: ── WeatherOracle Display (optional) ────────────────────────
set "WD_SCRIPT=%WO_DIR%weather_display.py"
if exist "%WD_SCRIPT%" (
    echo Registering WeatherOracle Display (web dashboard)...
    schtasks /create /tn "WeatherOracleDisplay" /tr "\"%PYTHON%\" \"%WD_SCRIPT%\"" /sc onlogon /rl highest /f /delay 0001:30
    if not errorlevel 1 (
        echo   [OK] Weather Display will auto-start 90 seconds after login
    ) else (
        echo   [FAIL] Could not create task.
    )
    echo.
)

echo ============================================
echo  Setup Complete
echo ============================================
echo.
echo Registered tasks:
schtasks /query /tn "WeatherOracle" /fo list 2>nul | findstr "TaskName Status"
schtasks /query /tn "StockOracle" /fo list 2>nul | findstr "TaskName Status"
schtasks /query /tn "WeatherOracleDisplay" /fo list 2>nul | findstr "TaskName Status"
echo.
echo To remove a task later:
echo   schtasks /delete /tn "WeatherOracle" /f
echo   schtasks /delete /tn "StockOracle" /f
echo   schtasks /delete /tn "WeatherOracleDisplay" /f
echo.
echo To test right now (starts immediately):
echo   schtasks /run /tn "WeatherOracle"
echo   schtasks /run /tn "StockOracle"
echo.
pause

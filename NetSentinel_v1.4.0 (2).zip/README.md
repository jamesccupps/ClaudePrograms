# ◆ NetSentinel

### AI-Powered Network Monitor & Intrusion Detection System for Windows

NetSentinel is a lightweight, desktop-based network security application that monitors all traffic on your computer, detects anomalies using machine learning, and alerts you to suspicious activity in real time.

![Status](https://img.shields.io/badge/status-v1.0-blue) ![Python](https://img.shields.io/badge/python-3.10+-green) ![Platform](https://img.shields.io/badge/platform-Windows-lightgrey)

---

## Features

### Real-Time Traffic Monitoring
- Full packet capture and inspection on all network interfaces
- Live bandwidth and packets-per-second charts
- Protocol breakdown visualization (TCP, UDP, ICMP, DNS, ARP, etc.)
- Bidirectional flow tracking with connection state monitoring
- Process identification — see which application owns each connection

### AI / Machine Learning Engine
- **Isolation Forest** anomaly detection trained on your normal traffic baseline
- **Statistical baseline profiling** with hourly and day-of-week patterns
- **Beaconing detection** — identifies regular C2-like communication patterns
- **DNS tunneling analysis** — entropy-based detection of data exfiltration via DNS
- **Adaptive learning** — the model retrains periodically as your baseline evolves
- **Feature extraction** — 18 traffic features including entropy, timing, ratios, and more

### Signature-Based Intrusion Detection (IDS)
- **Port scan detection** — flags hosts probing multiple ports in a time window
- **Brute force detection** — identifies repeated failed connection attempts
- **SYN flood detection** — detects denial-of-service attack patterns
- **ICMP flood detection** — flags ICMP-based DoS attempts
- **ARP spoofing detection** — alerts when MAC addresses change for known IPs
- **DNS anomaly detection** — suspicious TLDs, tunneling indicators
- **Data exfiltration alerts** — flags unusually large outbound transfers
- **Suspicious port detection** — known malware ports (4444, 1337, 31337, etc.)
- **Off-hours activity** — flags significant traffic during unusual times
- **Configurable IP/port blacklists and whitelists**

### Alert System
- Severity levels: LOW, MEDIUM, HIGH, CRITICAL
- Desktop notifications for HIGH/CRITICAL alerts
- Sound alerts for CRITICAL threats
- Alert cooldown to prevent duplicate flooding
- Export alerts to JSON or CSV
- Full alert history with search and filter

### Dashboard GUI
- Dark-themed professional interface
- 6 tabs: Dashboard, Alerts, Packet Log, Active Flows, ML Engine, Settings
- Real-time metric cards (packets, bandwidth, flows, threat level)
- Animated traffic and bandwidth charts
- Protocol distribution visualization
- All settings configurable from the GUI

---

## Quick Start

### Prerequisites
1. **Python 3.10+** — [Download from python.org](https://www.python.org/downloads/)
   - During install, check **"Add Python to PATH"**
2. **Npcap** — [Download from npcap.com](https://npcap.com/)
   - During install, check **"Install in WinPcap API-compatible mode"**

### Installation

**Option A: One-Click Setup (Recommended)**
```
1. Extract the NetSentinel folder to your desired location
2. Right-click setup.bat → "Run as administrator"
3. Follow the prompts
4. Double-click the desktop shortcut to launch
```

**Option B: Manual Setup**
```bash
# Navigate to the project folder
cd NetSentinel

# Install dependencies
pip install -r requirements.txt

# Run the application (as Administrator)
python main.py
```

**Option C: Build Standalone .exe**
```bash
# After installing dependencies, build the executable
build_exe.bat

# Run the output
dist\NetSentinel.exe
```

---

## How It Works

### Startup Sequence
1. NetSentinel requests Administrator privileges (needed for raw packet capture)
2. The application loads your configuration and any saved ML models/baselines
3. Click **START MONITORING** to begin packet capture

### Monitoring Pipeline
```
Packet Capture (Scapy)
    │
    ├──→ IDS Engine (real-time, per-packet)
    │        ├── Port scan detection
    │        ├── Brute force detection
    │        ├── Protocol anomaly checks
    │        ├── Blacklist matching
    │        └── Alert generation
    │
    ├──→ Flow Tracker
    │        ├── Bidirectional flow assembly
    │        ├── Connection state tracking
    │        └── Flow statistics
    │
    └──→ ML Engine (periodic, every 5 seconds)
             ├── Feature extraction (18 features)
             ├── Baseline comparison
             ├── Isolation Forest scoring
             ├── Beaconing analysis
             ├── DNS anomaly scoring
             └── Combined anomaly score → Alert
```

### Machine Learning Details

**Feature Vector (18 dimensions):**
| Feature | Description |
|---------|-------------|
| bytes_per_sec | Bandwidth consumption rate |
| packets_per_sec | Packet rate |
| avg_packet_size | Mean packet length |
| unique_dst_ports | Port diversity (high = scan) |
| unique_dst_ips | Destination diversity |
| syn_ratio | SYN packets vs total (high = scan/flood) |
| dns_query_rate | DNS queries per second |
| failed_conn_ratio | Connection failures (RST) |
| entropy_dst_port | Shannon entropy of destination ports |
| avg_inter_arrival | Mean time between packets |
| std_inter_arrival | Variability of packet timing |
| payload_ratio | Data vs overhead ratio |
| direction_asymmetry | Upload vs download imbalance |
| small_packet_ratio | Proportion of tiny packets |
| large_packet_ratio | Proportion of large packets |
| rst_ratio | TCP reset frequency |
| unique_protocols | Protocol diversity |
| encrypted_ratio | Proportion of encrypted traffic |

**Learning Process:**
1. During the initial learning period (default: 2 hours), the system builds a baseline
2. The Isolation Forest model trains once enough samples are collected (default: 200)
3. The model retrains periodically (default: every 60 minutes) to adapt
4. Hourly baselines capture time-of-day patterns (office hours vs night)
5. The baseline and model persist to disk and survive restarts

---

## Configuration

All settings are stored in `~/.netsentinel/config.json` and can be edited from the **Settings** tab in the GUI.

### Key Configuration Options

| Setting | Default | Description |
|---------|---------|-------------|
| `ml.anomaly_threshold` | 0.15 | Sensitivity (lower = more alerts) |
| `ml.min_samples_for_training` | 200 | Samples needed before model trains |
| `ml.retrain_interval_min` | 60 | Minutes between model retrains |
| `ids.port_scan_threshold` | 15 | Ports accessed to trigger scan alert |
| `ids.brute_force_threshold` | 10 | Failed connections to trigger alert |
| `alerts.cooldown_sec` | 30 | Minimum gap between duplicate alerts |
| `alerts.severity_filter` | LOW | Minimum severity to display |

### Whitelists & Blacklists
Add trusted or malicious IPs directly in the Settings tab, or edit `config.json`:
```json
{
  "whitelists": {
    "ips": ["192.168.1.1", "8.8.8.8"],
    "ports": [80, 443, 53]
  },
  "blacklists": {
    "ips": ["203.0.113.100"],
    "ports": [4444, 1337]
  }
}
```

---

## Project Structure

```
NetSentinel/
├── main.py              # Entry point (admin elevation, logging)
├── setup.bat            # One-click Windows installer
├── build_exe.bat        # Build standalone .exe
├── requirements.txt     # Python dependencies
├── README.md            # This file
│
├── src/
│   ├── __init__.py
│   ├── app.py           # Application orchestrator
│   ├── capture.py       # Packet capture engine (Scapy)
│   ├── config.py        # Configuration management
│   ├── ml_engine.py     # ML anomaly detection
│   ├── ids_engine.py    # Signature-based IDS rules
│   ├── alerts.py        # Alert management & notifications
│   └── gui.py           # Dashboard GUI (tkinter)
│
└── ~/.netsentinel/      # User data (created at runtime)
    ├── config.json      # Configuration
    ├── logs/            # Application logs
    ├── data/
    │   ├── alerts.json  # Alert history
    │   └── baseline.json # Traffic baseline
    └── models/
        ├── isolation_forest.pkl  # Trained ML model
        └── scaler.pkl            # Feature scaler
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Permission denied" on start | Right-click → Run as Administrator |
| No packets captured | Install Npcap with WinPcap compatibility mode |
| "Scapy not available" | `pip install scapy` |
| ML features disabled | `pip install scikit-learn numpy` |
| High CPU usage | Increase `analysis.stats_interval_sec` in settings |
| Too many alerts | Raise `alerts.cooldown_sec` or `ml.anomaly_threshold` |
| Model never trains | Lower `ml.min_samples_for_training` or wait longer |

---

## Security Notes

- NetSentinel is a **passive monitor only** — it does not modify, block, or intercept traffic
- All data stays local on your machine in `~/.netsentinel/`
- No data is sent anywhere externally
- The application requires Administrator privileges solely for raw packet capture access via Npcap

---

## License

MIT License — free for personal and commercial use.

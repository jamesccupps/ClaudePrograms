@echo off
title HVAC Network Scanner
echo ========================================
echo  HVAC Network Scanner - Full Discovery
echo ========================================
echo.

:: Use Python 3.13 
set PYVER=3.13
py -%PYVER% --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python %PYVER% not found.
    echo Install from https://python.org
    pause
    exit /b 1
)

echo Using Python %PYVER%
echo Checking dependencies...

:: pymodbus is optional (for Modbus deep scan)
py -%PYVER% -c "import pymodbus" >nul 2>&1
if %errorlevel% neq 0 (
    echo Installing pymodbus...
    py -%PYVER% -m pip install pymodbus -q
)

echo Dependencies OK.
echo.
echo Launching scanner...
echo.

:: Run from the script's directory
cd /d "%~dp0"
py -%PYVER% hvac_scanner.py

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Scanner exited with an error.
    pause
)

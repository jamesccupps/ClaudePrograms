# HVAC Network Scanner - Full Protocol Discovery

**BACnet/IP · BACnet MSTP · Modbus TCP · HVAC Services · SNMP**

Discovers and enumerates all HVAC-related devices on building automation networks.
Built for OCC facilities management (One City Center, Portland ME).

## Quick Start

1. Double-click `run_hvac_scanner.bat`
2. Click **SCAN**

That's it. No external BACnet libraries needed — all protocol handling is raw UDP/TCP.

## Features

- **BACnet/IP Discovery** — Raw UDP Who-Is/I-Am broadcast, device property reads, full object list enumeration with ReadProperty
- **BACnet MSTP Discovery** — Who-Is-Router-To-Network finds routers, then probes each remote DNET
- **Raw BACnet ReadProperty** — Zero-dependency implementation. Reads objectName, presentValue, units, description for every point
- **Modbus TCP Scanning** — Port 502 sweep, Device ID (FC 0x2B), holding/input register reads, coil status
- **HVAC Service Scanning** — 25+ ports: Niagara Fox, OPC UA, KNX, LonWorks, EtherNet/IP CIP, Siemens S7, MQTT, HTTP/HTTPS banner grab, SSH/Telnet/FTP
- **SNMP Discovery** — Raw UDP SNMPv1 GET sysDescr.0
- **Device Fingerprinting** — Cross-references vendor_id, instance patterns, max_apdu, MSTP routing, and TCP services to identify: Trane Tracer SC+/UC800/UC400, Siemens Desigo CC/PXC Automation Station/PXC Compact, JCI FEC/FAC, Contemporary Controls BASRT-B, Cimetrics BACstac, UniFi gateways
- **Default Credentials Database** — Trane, Siemens, JCI, BASRT-B, etc.
- **5-Tab UI** — All Devices, BACnet Points, Modbus Registers, Services, Raw JSON
- **Sortable Columns** — Click any header for ascending/descending sort (IP-aware, numeric-aware)
- **Right-Click Context Menu** — Open Web UI, Copy IP, Copy Creds, Ping, Show Details
- **Double-Click** — Opens device web interface in browser
- **Export** — CSV (utf-8-sig for Excel) and JSON (utf-8)

## Requirements

- **Python 3.10 - 3.13** (bat file targets 3.13 by default)
- **No BACnet libraries needed** — BAC0 and bacpypes are NOT required
- **pymodbus** (optional) — installed automatically by the bat file for Modbus deep scan
- **tkinter** — included with standard Python on Windows

## Default Configuration

| Field | Default | Notes |
|-------|---------|-------|
| Target Networks | `10.0.0.0/24, 10.0.1.0/24` | OCC HVAC VLAN 5 + VLAN 6 |
| Timeout | 5s | BACnet uses full timeout; services capped at 2s |
| BACnet | ✓ | Who-Is broadcast on port 47808 |
| MSTP | ✓ | Router discovery + DNET probing |
| Modbus | ✓ | TCP connect scan on port 502 |
| Services | ✓ | 25+ HVAC-related ports |
| SNMP | ✓ | SNMPv1 community=public |
| Deep | ✓ | Read all properties + object lists + registers |

## OCC Network Targets

- `10.0.0.0/24` — HVAC VLAN 5 (SC-1 at .19, SC-2 at .21, Siemens .176-.250)
- `10.0.1.0/24` — HVAC Extended VLAN 6 (Siemens .70-.200)
- `10.0.0.19/32` — Single device test (SC-1 only)

## Architecture

```
hvac_scanner.py (~2300 lines)
├── BACnetScanner        — Raw UDP Who-Is/I-Am/MSTP router discovery
├── RawBACnetReader      — Raw UDP ReadProperty (no BAC0/bacpypes)
├── ModbusScanner        — Raw TCP Modbus scanner
├── HVACServiceScanner   — TCP/HTTP service probing
├── SNMPScanner          — Raw UDP SNMP v1
├── fingerprint_device() — Device identification engine
├── HVACNetworkScanner   — tkinter GUI application
└── BACNET_VENDORS       — 30+ vendor IDs
    BACNET_UNITS         — ASHRAE 135 engineering units
    DEFAULT_CREDS        — Known default credentials
```

## Known OCC Scan Results (March 2026)

- **162 BACnet/IP devices** across VLANs 5+6
- **343 HVAC services** (HTTP, HTTPS, FTP, Telnet, S7, LonWorks)
- **Trane**: SC-1 (10.0.0.19, inst 33333), SC-2 (10.0.0.21, inst 22222)
- **Siemens Desigo**: ~120 PXC controllers, 2 management stations (.107/.108)
- **BASRT-B router**: 10.0.0.192 (inst 103100, vendor 245)
- **JCI FEC**: MSTP net 103 behind BASRT-B
- **Cimetrics BACstac**: 3x on MSTP net 102 behind .179

## Notes

- BACnet port 47808 binding: tries 47808 first (some devices hardcode I-Am responses there), falls back to ephemeral
- Deep scan caps at 200 objects per device to avoid timeout
- Trane SC+ flattens LonWorks sub-objects into BACnet Analog Inputs (pipe separator in names: `point|controller`)
- The 987653995582043462... values from Trane VAVs are IEEE 754 NaN/sentinel values for unconfigured auto-commissioning points
- CSV export uses utf-8-sig BOM for Excel compatibility

## Version History

- **v2.0** (2026-03-17) — Replaced BAC0 dependency with raw BACnet ReadProperty. Added MSTP discovery, service scanning, SNMP, device fingerprinting, default creds, sortable columns, context menu, re-fingerprint pass.
- **v1.0** (2026-03-17) — Initial build with BAC0-based deep scan, BACnet/IP + Modbus TCP.
